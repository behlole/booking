<?php
namespace Modules\Core\Models;

use App\BaseModel;

class MenuItem extends BaseModel
{
    protected $table = 'core_menu_items';
}