@extends('Email::layout')
@section('content')
    <div class="b-container">
        <div class="b-panel">
            <h3>Hello!</h3>
            <p>This is email test.</p>
        </div>
    </div>
@endsection
