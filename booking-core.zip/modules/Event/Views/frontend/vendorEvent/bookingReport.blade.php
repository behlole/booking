@extends('layouts.user')
@section('head')

@endsection
@section('content')
    @include('Event::frontend.vendorEvent.bookingReport.index')
@endsection
@section('footer')

@endsection
