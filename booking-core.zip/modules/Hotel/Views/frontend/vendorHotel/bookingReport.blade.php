@extends('layouts.user')
@section('head')

@endsection
@section('content')
    @include('Hotel::frontend.vendorHotel.bookingReport.index')
@endsection
@section('footer')

@endsection